import React from 'react';
import './BtnCarrito.css';

const BtnCarrito = () => {
    return (

        <div className="BtnCarrito">
            <img src="../public/c4.png" alt=""/> 
            </div>
    )
}

export default BtnCarrito;
