import React from 'react';
import "./Footer.css";


const footer = () => {
    return (


        <div className="General">

                <span>Con tu compra ayudas a todos los vendedores y la comunidad bugueña. ¡Gracias!</span>
        </div>


    )
}
export default footer;